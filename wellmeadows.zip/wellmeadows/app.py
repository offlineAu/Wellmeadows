from flask import Flask, render_template, request, jsonify, url_for, request
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from flask_cors import CORS
from sqlalchemy import Sequence
import requests
import logging

app = Flask(__name__, template_folder='templates')
CORS(app)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:admin@localhost/postgres'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['DEBUG'] = True
db = SQLAlchemy(app)

logging.basicConfig(level=logging.DEBUG)

class Ward(db.Model):
    __tablename__ = 'ward'
    ward_num = db.Column(db.String(10), primary_key=True)
    ward_name = db.Column(db.String(50), nullable=False)
    location = db.Column(db.Text, nullable=False)
    total_beds = db.Column(db.Integer, nullable=False)
    tele_xtn = db.Column(db.String(20), nullable=False)

class Staff(db.Model):
    __tablename__ = 'staff'
    staff_id = db.Column(db.String(10), primary_key=True)
    first_name = db.Column(db.String(100), nullable=False)
    last_name = db.Column(db.String(100), nullable=False)
    address = db.Column(db.Text, nullable=False)
    sex = db.Column(db.String(10), nullable=False)
    dob = db.Column(db.Date, nullable=False)
    phone = db.Column(db.String(20), nullable=False)
    nin = db.Column(db.String(20), nullable=False)
    position = db.Column(db.String(50), nullable=False)
    allocated = db.Column(db.String(50), nullable=False)
    current_salary = db.Column(db.Numeric(10, 2), nullable=False)
    salary_scale = db.Column(db.String(50), nullable=False)
    payment_frequency = db.Column(db.String(10), nullable=False)
    hours_per_week = db.Column(db.Numeric(5, 2), nullable=False)
    employment_type = db.Column(db.String(10), nullable=False)

class Qualification(db.Model):
    __tablename__ = 'qualifications'
    qualification_id = db.Column(db.Integer, Sequence('qualification_id_seq'), primary_key=True)
    staff_id = db.Column(db.String(10), db.ForeignKey('staff.staff_id'), nullable=False)
    qualification_type = db.Column(db.String(100), nullable=False)
    qualification_date = db.Column(db.Date, nullable=False)
    institution = db.Column(db.String(100), nullable=False)

class WorkExperience(db.Model):
    __tablename__ = 'work_experience'
    experience_id = db.Column(db.Integer, Sequence('experience_id_seq'), primary_key=True)
    staff_id = db.Column(db.String(10), db.ForeignKey('staff.staff_id'), nullable=False)
    work_position = db.Column(db.String(100), nullable=False)
    start_date = db.Column(db.Date, nullable=False)
    finish_date = db.Column(db.Date, nullable=False)
    organization = db.Column(db.String(100), nullable=False)

class WardAllocation(db.Model):
    __tablename__ = 'ward_allocation'
    allocation_id = db.Column(db.Integer, primary_key=True)
    week_beginning = db.Column(db.Date, nullable=False)
    ward_number = db.Column(db.String(10), db.ForeignKey('ward.ward_num'))
    ward_name = db.Column(db.String(50))
    location = db.Column(db.Text)
    charge_nurse = db.Column(db.String(10), db.ForeignKey('staff.staff_id'))
    tel_extn = db.Column(db.String(20))  # Added Tel Extn field

class StaffAllocation(db.Model):
    __tablename__ = 'staff_allocation'
    staff_allocation_id = db.Column(db.Integer, primary_key=True)
    allocation_id = db.Column(db.Integer, db.ForeignKey('ward_allocation.allocation_id'))
    staff_id = db.Column(db.String(10), db.ForeignKey('staff.staff_id'))
    staff_name = db.Column(db.String(200))
    address = db.Column(db.Text)
    tel_no = db.Column(db.String(20))
    position = db.Column(db.String(50))
    shift = db.Column(db.String(50))

    __table_args__ = (
        db.UniqueConstraint('allocation_id', 'staff_id', name='unique_allocation_staff'),
    )

class Patient(db.Model):
    __tablename__ = 'patients'
    patient_id = db.Column(db.String(10), primary_key=True)
    first_name = db.Column(db.String(100), nullable=False)
    last_name = db.Column(db.String(100), nullable=False)
    address = db.Column(db.Text, nullable=False)
    sex = db.Column(db.String(10), nullable=False)
    dob = db.Column(db.Date, nullable=False)
    phone = db.Column(db.String(20), nullable=False)
    marital_status = db.Column(db.String(20), nullable=False)
    date_registered = db.Column(db.Date, nullable=False)

class NextOfKin(db.Model):
    __tablename__ = 'next_of_kin'
    kin_id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.String(10), db.ForeignKey('patients.patient_id'), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    relationship = db.Column(db.String(50), nullable=False)
    address = db.Column(db.Text, nullable=False)
    phone = db.Column(db.String(20), nullable=False)

class LocalDoctor(db.Model):
    __tablename__ = 'local_doctors'
    doctor_id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.String(10), db.ForeignKey('patients.patient_id'), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    address = db.Column(db.Text, nullable=False)
    phone = db.Column(db.String(20), nullable=False)

class PatientAllocation(db.Model):
    __tablename__ = 'patient_allocation'
    patient_allocation_id = db.Column(db.Integer, primary_key=True)
    allocation_id = db.Column(db.Integer, db.ForeignKey('ward_allocation.allocation_id'))
    patient_number = db.Column(db.String(10))
    patient_name = db.Column(db.String(200))
    on_waiting_list = db.Column(db.String(10))
    expected_stay = db.Column(db.String(50))
    date_placed = db.Column(db.Date)
    date_leave = db.Column(db.Date)
    actual_leave = db.Column(db.Date)
    bed_number = db.Column(db.String(10))


@app.route('/get-charge-nurse')
def get_charge_nurse():
    ward_number = request.args.get('ward_number')
    ward_allocation = WardAllocation.query.filter_by(ward_number=ward_number).first()
    if ward_allocation:
        charge_nurse = Staff.query.filter_by(staff_id=ward_allocation.charge_nurse).first()
        if charge_nurse:
            charge_nurse_details = {
                'staff_id': charge_nurse.staff_id,
                'name': f"{charge_nurse.first_name} {charge_nurse.last_name}"
            }
            return jsonify({'charge_nurse': charge_nurse_details})
        else:
            return jsonify({'charge_nurse': None}), 404
    else:
        return jsonify({'charge_nurse': None}), 404

@app.route('/')
def index():
    staff_form_url = url_for('staff_form')
    return render_template('index.html', staff_form_url=staff_form_url)

@app.route('/staff-form')
def staff_form():
    staff_number = generate_staff_number()
    return render_template('staff-form.html', staff_number=staff_number)

@app.route('/submit-staff-form', methods=['POST'])
def submit_staff_form():
    try:
        # Log the entire request.form data
        print("Received form data:", request.form)

        # Attempt to get the staff_id from the form
        staff_id = request.form.get('staff_id')
        print("Received staff_id:", staff_id)

        if not staff_id:
            return jsonify({"error": "Missing required field: staff_id"}), 400

        # Check if the staff_id already exists in the database
        existing_staff = Staff.query.filter_by(staff_id=staff_id).first()
        if existing_staff:
            return jsonify({"error": "Staff ID already exists"}), 400

        # Process the form data
        first_name = request.form['first_name']
        last_name = request.form['last_name']
        address = request.form['address']
        sex = request.form['sex']
        dob = datetime.strptime(request.form['dob'], '%Y-%m-%d')
        phone = request.form['phone']
        nin = request.form['nin']
        position = request.form['position']
        allocated = request.form['allocated']
        current_salary = request.form['current_salary']
        salary_scale = request.form['salary_scale']
        payment_frequency = request.form['payment_frequency']
        hours_per_week = request.form['hours_per_week']
        employment_type = request.form['employment_type']

        new_staff = Staff(
            staff_id=staff_id, first_name=first_name, last_name=last_name, address=address, sex=sex, dob=dob,
            phone=phone, nin=nin, position=position, allocated=allocated, current_salary=current_salary,
            salary_scale=salary_scale, payment_frequency=payment_frequency, hours_per_week=hours_per_week,
            employment_type=employment_type
        )
        db.session.add(new_staff)

        # Commit the session to ensure staff is saved
        db.session.commit()

        # Qualifications
        qualification_types = request.form.getlist('qualification_type[]')
        qualification_dates = request.form.getlist('qualification_date[]')
        institutions = request.form.getlist('institution[]')

        for q_type, q_date, institution in zip(qualification_types, qualification_dates, institutions):
            qualification_date = datetime.strptime(q_date, '%Y-%m-%d')
            new_qualification = Qualification(
                staff_id=new_staff.staff_id,
                qualification_type=q_type,
                qualification_date=qualification_date,
                institution=institution
            )
            db.session.add(new_qualification)
        
        # Work Experience
        work_positions = request.form.getlist('work_position[]')
        start_dates = request.form.getlist('start_date[]')
        finish_dates = request.form.getlist('finish_date[]')
        organizations = request.form.getlist('organization[]')

        for w_position, s_date, f_date, organization in zip(work_positions, start_dates, finish_dates, organizations):
            start_date = datetime.strptime(s_date, '%Y-%m-%d')
            finish_date = datetime.strptime(f_date, '%Y-%m-%d')
            new_experience = WorkExperience(
                staff_id=new_staff.staff_id,
                work_position=w_position,
                start_date=start_date,
                finish_date=finish_date,
                organization=organization
            )
            db.session.add(new_experience)

        # Commit the session again to save qualifications and work experiences
        db.session.commit()

        return jsonify({'message': 'Staff added successfully!'}), 200

    except KeyError as e:
        db.session.rollback()  # Rollback the session in case of an error
        return jsonify({'error': f'Missing required field: {e.args[0]}'}), 400

    except Exception as e:
        db.session.rollback()  # Rollback the session in case of an error
        return jsonify({'error': str(e)}), 500

    
@app.route('/get-staff')
def get_staff():
    staff = Staff.query.all()
    staff_list = [{'staff_id': s.staff_id, 'first_name': s.first_name, 'last_name': s.last_name, 'position': s.position} for s in staff]
    return jsonify({'staff': staff_list})

    
def generate_staff_number():
    last_staff = Staff.query.order_by(Staff.staff_id.desc()).first()
    if last_staff:
        # Strip any non-digit characters if needed, then convert to integer
        last_id = int(''.join(filter(str.isdigit, last_staff.staff_id)))
        new_id = last_id + 1
        return f"S{new_id:03d}"  # Convert back to the formatted string
    else:
        return "S001"

@app.route('/generate-staff-number')
def generate_staff_number_route():
    staff_number = generate_staff_number()
    return jsonify({'staff_number': staff_number})

@app.route('/ward-staff')
def ward_staff():
    return render_template('ward-staff.html')

@app.route('/submit-ward-allocation', methods=['POST'])
def submit_ward_allocation():
    try:
        form_data = request.form.to_dict()
        app.logger.info(f"Received form data: {form_data}")

        week_beginning = request.form.get('weekBeginning')
        ward_number = request.form.get('wardNumber')
        ward_name = request.form.get('wardName')
        location = request.form.get('location')
        charge_nurse_id = request.form.get('chargeNurse')
        tel_extn = request.form.get('telExtn')

        # Logging each field individually
        app.logger.info(f"weekBeginning: {week_beginning}")
        app.logger.info(f"wardNumber: {ward_number}")
        app.logger.info(f"wardName: {ward_name}")
        app.logger.info(f"location: {location}")
        app.logger.info(f"chargeNurse: {charge_nurse_id}")
        app.logger.info(f"telExtn: {tel_extn}")

        if not (week_beginning and ward_number and ward_name and location and charge_nurse_id and tel_extn):
            return jsonify({'error': 'Missing required fields'}), 400

        ward_allocation = WardAllocation(
            week_beginning=datetime.strptime(week_beginning, '%Y-%m-%d'),
            ward_number=ward_number,
            ward_name=ward_name,
            location=location,
            charge_nurse=charge_nurse_id,
            tel_extn=tel_extn
        )

        db.session.add(ward_allocation)
        db.session.commit()

        return jsonify({'message': 'Ward Allocation submitted successfully!'}), 200
    except Exception as e:
        db.session.rollback()
        app.logger.error(f"Error processing ward allocation form data: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/submit-staff-allocation', methods=['POST'])
def submit_staff_allocation():
    try:
        form_data = request.form.to_dict()
        app.logger.info(f"Received staff allocation form data: {form_data}")

        allocation_id = request.form['allocationId']
        staff_id = request.form['staffId']
        staff_name = request.form['staffName']
        address = request.form['address']
        tel_no = request.form['telNo']
        position = request.form['position']
        shift = request.form['shift']

        # Check if required fields are missing
        if not (allocation_id and staff_id and staff_name and address and tel_no and position and shift):
            return jsonify({'error': 'Missing required fields'}), 400

        # Create a new StaffAllocation instance
        staff_allocation = StaffAllocation(
            allocation_id=allocation_id,
            staff_id=staff_id,
            staff_name=staff_name,
            address=address,
            tel_no=tel_no,
            position=position,
            shift=shift
        )

        db.session.add(staff_allocation)
        db.session.commit()

        return jsonify({'message': 'Staff Allocation submitted successfully!'}), 200
    except Exception as e:
        db.session.rollback()
        app.logger.error(f"Error processing staff allocation form data: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/submit-combined-allocation', methods=['POST'])
def submit_combined_allocation():
    try:
        data = request.json
        app.logger.info(f"Received combined form data: {data}")

        # Process ward allocation data
        week_beginning = data.get('weekBeginning')
        ward_number = data.get('wardNumber')
        ward_name = data.get('wardName')
        location = data.get('location')
        charge_nurse_id = data.get('chargeNurse')
        tel_extn = data.get('telExtn')

        if not (week_beginning and ward_number and ward_name and location and charge_nurse_id and tel_extn):
            return jsonify({'error': 'Missing required ward allocation fields'}), 400

        ward_allocation = WardAllocation(
            week_beginning=datetime.strptime(week_beginning, '%Y-%m-%d'),
            ward_number=ward_number,
            ward_name=ward_name,
            location=location,
            charge_nurse=charge_nurse_id,
            tel_extn=tel_extn
        )
        db.session.add(ward_allocation)
        db.session.flush()  # Get the ID before commit

        # Process staff allocation data
        staff_allocations = data.get('staffAllocation', [])
        for staff in staff_allocations:
            staff_allocation = StaffAllocation(
                allocation_id=ward_allocation.allocation_id,
                staff_id=staff['staffId'],
                staff_name=staff['staffName'],
                address=staff['address'],
                tel_no=staff['telNo'],
                position=staff['position'],
                shift=staff['shift']
            )
            db.session.add(staff_allocation)

        db.session.commit()

        return jsonify({'message': 'Combined Allocation submitted successfully!'}), 200
    except Exception as e:
        db.session.rollback()
        app.logger.error(f"Error processing combined form submission: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/get-wards')
def get_wards():
    wards = Ward.query.all()
    ward_list = [{'ward_num': ward.ward_num, 'ward_name': ward.ward_name, 'location': ward.location, 'tele_xtn': ward.tele_xtn} for ward in wards]
    return jsonify({'wards': ward_list})

@app.route('/get-ward-details')
def get_ward_details():
    ward_num = request.args.get('ward_num')
    app.logger.debug(f"Received ward_num: {ward_num}")
    ward = Ward.query.filter_by(ward_num=ward_num).first()
    if ward:
        ward_details = {'ward_num': ward.ward_num, 'ward_name': ward.ward_name, 'location': ward.location, 'tele_xtn': ward.tele_xtn}
        return jsonify(ward_details)
    else:
        app.logger.debug("Ward not found")
        return jsonify({'error': 'Ward not found'}), 404


@app.route('/get-staff-details')
def get_staff_details():
    staff_id = request.args.get('staff_id')
    app.logger.debug(f"Received staff_id: {staff_id}")
    staff = Staff.query.filter_by(staff_id=staff_id).first()
    if staff:
        staff_details = {
            'staff_id': staff.staff_id,
            'first_name': staff.first_name,
            'last_name': staff.last_name,
            'address': staff.address,
            'phone': staff.phone,
            'position': staff.position
        }
        return jsonify(staff_details)
    else:
        app.logger.debug("Staff not found")
        return jsonify({'error': 'Staff not found'}), 404


@app.route('/patient-med-form')
def patient_med_form():
    return render_template('patient-med-form.html')

@app.route('/requisition-form', methods=['GET', 'POST'])
def requisition_form():
    try:
        if request.method == 'POST':
            data = request.get_json()
            drug_name = data.get('drug-name')
            logging.debug(f"Fetching details for drug: {drug_name}")
            drug_details = fetch_drug_details(drug_name)
            logging.debug(f"Drug details: {drug_details}")
            return jsonify(drug_details)
        return render_template('requisition-form.html')
    except Exception as e:
        logging.error(f"Error in requisition_form: {e}")
        return jsonify({'error': 'Internal Server Error'}), 500

def fetch_drug_details(drug_name):
    try:
        # DailyMed endpoint to search SPLs by drug name
        search_endpoint = f"https://dailymed.nlm.nih.gov/dailymed/services/v2/spls.json?drug_name={drug_name}"
        search_response = requests.get(search_endpoint)
        search_response.raise_for_status()
        search_data = search_response.json()

        if search_data.get('data'):
            spl_id = search_data['data'][0]['setid']
            details_endpoint = f"https://dailymed.nlm.nih.gov/dailymed/services/v2/spls/{spl_id}.json"
            headers = {
                'Accept': 'application/json'
            }
            details_response = requests.get(details_endpoint, headers=headers)
            details_response.raise_for_status()
            details_data = details_response.json()

            # Extract relevant details
            drug_info = details_data.get('data', [{}])[0]
            description = drug_info.get('description', 'Description not found')
            dosage = drug_info.get('dosage', 'Dosage not found')
            route = drug_info.get('route', 'Method of Admin not found')

            # Hypothetical API call to get cost and quantity details
            # For the sake of this example, let's assume DrugBank API is used
            drugbank_endpoint = f"https://api.drugbank.com/v1/drugs/{drug_name}"
            drugbank_response = requests.get(drugbank_endpoint)
            drugbank_response.raise_for_status()
            drugbank_data = drugbank_response.json()

            cost_per_unit = drugbank_data.get('cost_per_unit', 'Cost data not available')
            quantity = drugbank_data.get('quantity', 'Quantity data not available')

            return {
                'name': drug_name,
                'description': description,
                'dosage': dosage,
                'method_of_admin': route,
                'cost_per_unit': cost_per_unit,
                'quantity': quantity
            }
        return {
            'name': drug_name,
            'description': 'Description not found',
            'dosage': 'Dosage not found',
            'method_of_admin': 'Method of Admin not found',
            'cost_per_unit': 'Cost data not available',
            'quantity': 'Quantity data not available'
        }
    except requests.exceptions.RequestException as e:
        logging.error(f"Error fetching drug details from DailyMed: {e}")
        return {
            'name': drug_name,
            'description': 'Description not found',
            'dosage': 'Dosage not found',
            'method_of_admin': 'Method of Admin not found',
            'cost_per_unit': 'Cost data not available',
            'quantity': 'Quantity data not available'
        }
        
@app.route('/patient-allocation')
def patient_allocation():
    return render_template('patient-allocation.html')

@app.route('/submit-combined-patient-allocation', methods=['POST'])
def submit_combined_patient_allocation():
    try:
        data = request.json
        app.logger.info(f"Received combined patient allocation data: {data}")

        # Process ward allocation data
        week_beginning = data.get('weekBeginning')
        ward_number = data.get('wardNumber')
        ward_name = data.get('wardName')
        location = data.get('location')
        charge_nurse_id = data.get('chargeNurse')
        tel_extn = data.get('telExtn')

        if not (week_beginning and ward_number and ward_name and location and charge_nurse_id and tel_extn):
            return jsonify({'error': 'Missing required ward allocation fields'}), 400

        ward_allocation = WardAllocation(
            week_beginning=datetime.strptime(week_beginning, '%Y-%m-%d'),
            ward_number=ward_number,
            ward_name=ward_name,
            location=location,
            charge_nurse=charge_nurse_id,
            tel_extn=tel_extn
        )
        db.session.add(ward_allocation)
        db.session.flush()  # Get the ID before commit

        # Process patient allocation data
        patient_allocations = data.get('patientAllocation', [])
        for patient in patient_allocations:
            patient_allocation = PatientAllocation(
                allocation_id=ward_allocation.allocation_id,
                patient_number=patient['patientNumber'],
                patient_name=patient['patientName'],
                on_waiting_list=patient['onWaitingList'],
                expected_stay=patient['expectedStay'],
                date_placed=datetime.strptime(patient['datePlaced'], '%Y-%m-%d'),
                date_leave=datetime.strptime(patient['dateLeave'], '%Y-%m-%d'),
                actual_leave=datetime.strptime(patient['actualLeave'], '%Y-%m-%d'),
                bed_number=patient['bedNumber']
            )
            db.session.add(patient_allocation)

        db.session.commit()

        return jsonify({'message': 'Combined Patient Allocation submitted successfully!'}), 200
    except Exception as e:
        db.session.rollback()
        app.logger.error(f"Error processing combined form submission: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/get-patients')
def get_patients():
    patients = Patient.query.all()
    patient_list = [{'patient_id': p.patient_id, 'first_name': p.first_name, 'last_name': p.last_name} for p in patients]
    return jsonify({'patients': patient_list})

@app.route('/get-patient-details')
def get_patient_details():
    patient_id = request.args.get('patient_id')
    patient = Patient.query.filter_by(patient_id=patient_id).first()
    
    if patient:
        full_name = "{} {}".format(patient.first_name, patient.last_name)
        
        patient_details = {
            'patient_id': patient.patient_id,
            'patient_name': full_name
        }
        
        return jsonify(patient_details)
    else:
        return jsonify({'error': 'Patient not found'}), 404

@app.route('/patient-registration')
def patient_registration():
    patient_number = generate_patient_number()
    return render_template('patient-registration.html', patient_number=patient_number)

def generate_patient_number():
    last_patient = Patient.query.order_by(Patient.patient_id.desc()).first()
    if last_patient:
        last_id = int(''.join(filter(str.isdigit, last_patient.patient_id)))
        new_id = last_id + 1
        return f"P{new_id:03d}"
    else:
        return "P001"

@app.route('/generate-patient-number')
def generate_patient_number_route():
    patient_number = generate_patient_number()
    return jsonify({'patient_number': patient_number})

@app.route('/submit-patient-form', methods=['POST'])
def submit_patient_form():
    try:
        print("Received form data:", request.form)
        patient_id = request.form.get('patient_id')
        print("Received patient_id:", patient_id)
        if not patient_id:
            return jsonify({"error": "Missing required field: patient_id"}), 400

        existing_patient = Patient.query.filter_by(patient_id=patient_id).first()
        if existing_patient:
            return jsonify({"error": "Patient ID already exists"}), 400

        first_name = request.form['first_name']
        last_name = request.form['last_name']
        address = request.form['address']
        sex = request.form['sex']
        dob = datetime.strptime(request.form['dob'], '%Y-%m-%d')
        phone = request.form['phone']
        marital_status = request.form['marital']
        date_registered = datetime.strptime(request.form['date_registered'], '%Y-%m-%d')

        new_patient = Patient(
            patient_id=patient_id, first_name=first_name, last_name=last_name, address=address, sex=sex, dob=dob,
            phone=phone, marital_status=marital_status, date_registered=date_registered
        )
        db.session.add(new_patient)
        db.session.commit()

        kin_name = request.form['kin_name']
        kin_relationship = request.form['kin_relationship']
        kin_address = request.form['kin_address']
        kin_phone = request.form['kin_phone']

        new_kin = NextOfKin(
            patient_id=new_patient.patient_id, name=kin_name, relationship=kin_relationship, address=kin_address,
            phone=kin_phone
        )
        db.session.add(new_kin)

        doctor_name = request.form['doctor_name']
        doctor_address = request.form['doctor_address']
        doctor_phone = request.form['doctor_phone']

        new_doctor = LocalDoctor(
            patient_id=new_patient.patient_id, name=doctor_name, address=doctor_address, phone=doctor_phone
        )
        db.session.add(new_doctor)
        db.session.commit()

        return jsonify({'message': 'Patient added successfully!'}), 200

    except KeyError as e:
        db.session.rollback()
        return jsonify({'error': f'Missing required field: {e.args[0]}'}), 400

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
