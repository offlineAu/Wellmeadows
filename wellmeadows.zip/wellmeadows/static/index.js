document.addEventListener('DOMContentLoaded', () => {
    const services = document.querySelectorAll('.service');
    const popup = document.getElementById('popup');
    const popupContent = document.getElementById('popup-content');
    const closePopup = document.getElementById('close-popup');
    let staffOptions = [];

    console.log("Services elements found:", services.length);
    console.log("Popup element found:", popup !== null);
    console.log("Popup content element found:", popupContent !== null);
    console.log("Close popup element found:", closePopup !== null);

    services.forEach(service => {
        service.addEventListener('click', () => {
            services.forEach(s => s.classList.remove('border-blue-500', 'text-blue-500'));
            service.classList.add('border-blue-500', 'text-blue-500');
            fetch(service.dataset.popupContent)
                .then(response => response.text())
                .then(data => {
                    popupContent.innerHTML = data;
                    popup.classList.remove('hidden');
                    initializePopupContent();
                })
                .catch(error => console.error('Error loading popup content:', error));
        });
    });

    closePopup.addEventListener('click', () => {
        popup.classList.add('hidden');
    });

    async function fetchDrugDetails() {
        const drugName = document.getElementById('drug-name').value;
        const response = await fetch('/requisition-form', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ 'drug-name': drugName }),
        });
    
        if (response.ok) {
            const data = await response.json();
            document.getElementById('description').textContent = data.description;
            document.getElementById('dosage').textContent = data.dosage;
            document.getElementById('method-of-admin').textContent = data.method_of_admin;
            document.getElementById('cost-per-unit').textContent = data.cost_per_unit;
            document.getElementById('quantity').textContent = data.quantity;
        } else {
            console.error('Failed to fetch drug details');
        }
    }
    
    
    function initializeFormSubmissions() {
        const submitBtn = document.querySelector('button[id="submit-btn"]');
        
        if (submitBtn) {
            submitBtn.addEventListener('click', function(event) {
                event.preventDefault(); // Prevent default form submission
        
                const wardAllocationData = getWardAllocationData();
                const staffAllocationData = getStaffAllocationData();
        
                if (wardAllocationData && staffAllocationData) {
                    const combinedData = { ...wardAllocationData, staffAllocation: staffAllocationData };
                    submitCombinedData(combinedData);
                } else {
                    console.error('Ward Allocation or Staff Allocation data is missing.');
                }
            });
        } else {
            console.error("Submit button not found.");
        }
    }
    
    function getWardAllocationData() {
        const weekBeginning = document.getElementById('weekBeginning').value;
        const wardNumber = document.getElementById('wardNumber').value;
        const chargeNurse = document.getElementById('chargeNurse').value;
    
        const wardName = document.getElementById('wardName').textContent;
        const location = document.getElementById('location').textContent;
        const telExtn = document.getElementById('telExtn').textContent;
    
        if (weekBeginning && wardNumber && wardName && location && chargeNurse && telExtn) {
            return {
                weekBeginning,
                wardNumber,
                wardName,
                location,
                chargeNurse,
                telExtn
            };
        } else {
            console.error('Missing required ward allocation form fields', {
                weekBeginning,
                wardNumber,
                wardName,
                location,
                chargeNurse,
                telExtn
            });
            return null;
        }
    }
    
    function getStaffAllocationData() {
        const rows = document.querySelectorAll('#staffTable tr');
        const staffAllocations = [];
    
        rows.forEach(row => {
            const staffId = row.querySelector('select[name="staff_id"]')?.value;
            const staffName = row.cells[1].textContent;
            const address = row.cells[2].textContent;
            const telNo = row.cells[3].textContent;
            const position = row.cells[4].textContent;
            const shift = row.querySelector('select[name="shift"]')?.value;
    
            if (staffId && staffName && address && telNo && position && shift) {
                staffAllocations.push({
                    staffId,
                    staffName,
                    address,
                    telNo,
                    position,
                    shift
                });
            } else {
                console.error('Missing required staff allocation form fields', {
                    staffId,
                    staffName,
                    address,
                    telNo,
                    position,
                    shift
                });
            }
        });
    
        if (staffAllocations.length > 0) {
            return staffAllocations;
        } else {
            console.error('No valid staff allocation data found');
            return null;
        }
    }
    
    function submitCombinedData(data) {
        fetch('/submit-combined-allocation', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                console.error('Error submitting form:', data.error);
            } else {
                console.log('Form submitted successfully:', data.message);
                window.location.href = '/';
            }
        })
        .catch(error => console.error('Error:', error));
    }    

    function initializeWardDropdown() {
        const wardDropdown = document.getElementById('wardNumber');
        if (wardDropdown) {
            console.log("Element with ID 'wardNumber' found.");
            fetch('/get-wards')
                .then(response => response.json())
                .then(data => {
                    data.wards.forEach(ward => {
                        const option = document.createElement('option');
                        option.value = ward.ward_num;
                        option.textContent = ward.ward_num;
                        wardDropdown.appendChild(option);
                    });
                    if (wardDropdown.options.length > 1) {
                        wardDropdown.selectedIndex = 1;
                        wardDropdown.dispatchEvent(new Event('change'));
                    }
                })
                .catch(error => console.error('Error fetching wards:', error));
        } else {
            console.error("Element with ID 'wardNumber' not found.");
        }
    }

    function initializeChargeNurseDropdown() {
        const chargeNurseDropdown = document.getElementById('chargeNurse');
    
        fetch('/get-staff')
            .then(response => response.json())
            .then(data => {
                staffOptions = data.staff;
                data.staff.forEach(staff => {
                    if (staff.position === 'Charge Nurse') {
                        const option = document.createElement('option');
                        option.value = staff.staff_id;
                        option.textContent = `${staff.first_name} ${staff.last_name}`;
                        chargeNurseDropdown.appendChild(option);
                    }
                });
    
                chargeNurseDropdown.addEventListener('change', function() {
                    const staffId = chargeNurseDropdown.value;
                    if (staffId) {
                        fetch(`/get-staff-details?staff_id=${staffId}`)
                            .then(response => {
                                if (!response.ok) {
                                    throw new Error('Network response was not ok');
                                }
                                return response.json();
                            })
                            .then(data => {
                                document.getElementById('staffNumber').textContent = data.staff_id;
                            })
                            .catch(error => console.error('Error fetching staff details:', error));
                    } else {
                        console.error('Staff ID is empty');
                    }
                });
            })
            .catch(error => console.error('Error fetching staff:', error));
    }
    
    function initializeWardDetailsListener() {
        const wardNumberElement = document.getElementById('wardNumber');
        if (wardNumberElement) {
            wardNumberElement.addEventListener('change', function() {
                const wardNumber = wardNumberElement.value;
                if (wardNumber) {
                    fetch(`/get-ward-details?ward_num=${wardNumber}`)
                        .then(response => response.json())
                        .then(data => {
                            const wardNameElement = document.getElementById('wardName');
                            const locationElement = document.getElementById('location');
                            const telExtnElement = document.getElementById('telExtn');
    
                            if (wardNameElement && locationElement && telExtnElement) {
                                wardNameElement.textContent = data.ward_name;
                                locationElement.textContent = data.location;
                                telExtnElement.textContent = data.tele_xtn;
                            } else {
                                console.error('One or more span elements for ward details are missing');
                            }
                        })
                        .catch(error => console.error('Error fetching ward details:', error));
                } else {
                    console.error('Ward number is empty');
                }
            });
        } else {
            console.error("Element with ID 'wardNumber' not found for adding event listener.");
        }
    }

    function initializeStaffDropdown(staffDropdownRow, staffDropdown) {
        fetch('/get-staff')
            .then(response => response.json())
            .then(data => {
                const blankOption = document.createElement('option');
                blankOption.value = '';
                blankOption.textContent = 'Select Staff';
                staffDropdown.appendChild(blankOption);
    
                data.staff.forEach(staff => {
                    if (staff.position !== 'Charge Nurse') {
                        const option = document.createElement('option');
                        option.value = staff.staff_id;
                        option.textContent = `${staff.staff_id}`;
                        staffDropdown.appendChild(option);
                    }
                });
    
                staffDropdown.addEventListener('change', function() {
                    const staffId = staffDropdown.value;
                    if (staffId) {
                        fetch(`/get-staff-details?staff_id=${staffId}`)
                            .then(response => {
                                if (!response.ok) {
                                    throw new Error('Network response was not ok');
                                }
                                return response.json();
                            })
                            .then(data => {
                                const cells = staffDropdownRow.cells;
                                cells[0].querySelector('select[name="staff_id"]').value = data.staff_id;
                                cells[1].textContent = `${data.first_name} ${data.last_name}`;
                                cells[2].textContent = data.address;
                                cells[3].textContent = data.phone;
                                cells[4].textContent = data.position;
                            })
                            .catch(error => console.error('Error fetching staff details:', error));
                    } else {
                        console.error('Staff ID is empty');
                    }
                });
            })
            .catch(error => console.error('Error fetching staff:', error));
    }
    
    function addNewRow() {
        const table = document.getElementById('staffTable');
        if (table.rows.length >= 5) {
            alert("You cannot add more than 5 staff members.");
            return;
        }
    
        const newRow = table.insertRow();
        let newCell;
    
        newCell = newRow.insertCell(0);
        const select = document.createElement('select');
        select.className = 'form-control';
        select.name = 'staff_id';
        newCell.appendChild(select);
    
        newCell = newRow.insertCell(1);
        newCell.contentEditable = 'false';
        newCell.innerText = '';
    
        newCell = newRow.insertCell(2);
        newCell.contentEditable = 'false';
        newCell.innerText = '';
    
        newCell = newRow.insertCell(3);
        newCell.contentEditable = 'false';
        newCell.innerText = '';
    
        newCell = newRow.insertCell(4);
        newCell.contentEditable = 'false';
        newCell.innerText = '';
    
        newCell = newRow.insertCell(5);
        const shiftSelect = document.createElement('select');
        shiftSelect.className = 'form-control';
        shiftSelect.name = 'shift';
        const shifts = ['Late', 'Early', 'Night'];
        shifts.forEach(shift => {
            const option = document.createElement('option');
            option.value = shift;
            option.text = shift;
            shiftSelect.appendChild(option);
        });
        newCell.appendChild(shiftSelect);
    
        newCell = newRow.insertCell(6);
        const deleteBtn = document.createElement('button');
        deleteBtn.type = 'button';
        deleteBtn.className = 'btn btn-danger delete-row-btn';
        deleteBtn.innerHTML = '<i class="bi bi-trash"></i>';
        deleteBtn.onclick = function() {
            table.deleteRow(newRow.rowIndex - 1);
        };
        newCell.appendChild(deleteBtn);

        initializeStaffDropdown(newRow, select);
    }

    document.querySelector('form').onsubmit = function() {
        const positions = Array.from(document.querySelectorAll('tbody tr td:nth-child(5)')).map(td => td.innerText);
        const doctorCount = positions.filter(pos => pos.toLowerCase().includes('doctor')).length;
        const specialistCount = positions.filter(pos => pos.toLowerCase().includes('specialist')).length;

        if (doctorCount > 1 || specialistCount > 1) {
            alert("You cannot have more than 1 doctor and 1 specialist.");
            return false;
        }

        // Disable the selected staff to prevent re-selection
        const selectedStaffIds = Array.from(document.querySelectorAll('select[name="staff_id"]')).map(select => select.value);
        staffOptions = staffOptions.filter(option => !selectedStaffIds.includes(option.staff_id));

        return true;
    };

    function addFormSubmitListener() {
        const staffForm = document.getElementById('staffForm');
        if (staffForm) {
            console.log("Staff form found:", staffForm);
            staffForm.addEventListener('submit', (event) => {
                const staffIdInput = document.getElementById('staff_id');
                console.log("Staff ID input value before submit:", staffIdInput ? staffIdInput.value : "not found");
                if (!staffIdInput.value) {
                    event.preventDefault();
                    console.error("Staff ID is missing. Form submission prevented.");
                } else {
                    console.log("Form submitted with staff ID:", staffIdInput.value);
                }
            });
        } else {
            console.error("Element with ID 'staffForm' not found.");
        }
    }

    function fetchStaffNumber() {
        fetch('/generate-staff-number')
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                console.log('Staff number:', data.staff_number);
                const staffIdInput = document.getElementById('staff_id');
                if (staffIdInput) {
                    staffIdInput.value = String(data.staff_number);
                    console.log('Staff ID set to:', staffIdInput.value);
                } else {
                    console.error("Element with ID 'staff_id' not found.");
                }
            })
            .catch(error => console.error('Error fetching staff number:', error));
    }

    function addPatientFormSubmitListener() {
    const patientForm = document.getElementById('patientForm');
    if (patientForm) {
        console.log("Patient form found:", patientForm);
        patientForm.addEventListener('submit', (event) => {
            const patientIdInput = document.getElementById('patient_id');
            console.log("Patient ID input value before submit:", patientIdInput ? patientIdInput.value : "not found");
            if (!patientIdInput.value) {
                event.preventDefault();
                console.error("Patient ID is missing. Form submission prevented.");
            } else {
                console.log("Form submitted with patient ID:", patientIdInput.value);
            }
        });
    } else {
        console.error("Element with ID 'patientForm' not found.");
    }
}

    function fetchPatientNumber() {
        fetch('/generate-patient-number')
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                console.log('Patient number:', data.patient_number);
                const patientIdInput = document.getElementById('patient_id');
                if (patientIdInput) {
                    patientIdInput.value = String(data.patient_number);
                    console.log('Patient ID set to:', patientIdInput.value);
                } else {
                    console.error("Element with ID 'patient_id' not found.");
                }
            })
            .catch(error => console.error('Error fetching patient number:', error));
    }

    function initializePatientFormSubmissions() {
        const PatientsubmitBtn = document.getElementById('patient-submit-btn');
    
        if (PatientsubmitBtn) {
            PatientsubmitBtn.addEventListener('click', function (event) {
                event.preventDefault(); // Prevent default form submission
    
                const wardAllocationData = getWardAllocationData();
                const patientAllocationData = getPatientAllocationData();
    
                if (wardAllocationData && patientAllocationData) {
                    const combinedData = { ...wardAllocationData, patientAllocation: patientAllocationData };
                    submitCombinedData(combinedData);
                } else {
                    console.error('Ward Allocation or Patient Allocation data is missing.');
                }
            });
        } else {
            console.error("Submit button not found.");
        }
    }
    
    function getWardAllocationData() {
        const weekBeginning = document.getElementById('weekBeginning').value;
        const wardNumber = document.getElementById('wardNumber').value;
        const chargeNurse = document.getElementById('chargeNurse').value;
    
        const wardName = document.getElementById('wardName').textContent;
        const location = document.getElementById('location').textContent;
        const telExtn = document.getElementById('telExtn').textContent;
    
        if (weekBeginning && wardNumber && wardName && location && chargeNurse && telExtn) {
            return {
                weekBeginning,
                wardNumber,
                wardName,
                location,
                chargeNurse,
                telExtn
            };
        } else {
            console.error('Missing required ward allocation form fields', {
                weekBeginning,
                wardNumber,
                wardName,
                location,
                chargeNurse,
                telExtn
            });
            return null;
        }
    }
    
    function getPatientAllocationData() {
        const formElement = document.getElementById('patientAllocationForm');
        const formData = new FormData(formElement);
        const patientAllocations = [];
    
        document.querySelectorAll('#patientTable tr').forEach(row => {
            const patientNumber = row.querySelector('select[name="patientNumber"]').value;
            const patientName = row.cells[1].textContent;
            const onWaitingList = row.querySelector('input[name="onWaitingList"]').value;
            const expectedStay = row.querySelector('input[name="expectedStay"]').value;
            const datePlaced = row.querySelector('input[name="datePlaced"]').value;
            const dateLeave = row.querySelector('input[name="dateLeave"]').value;
            const actualLeave = row.querySelector('input[name="actualLeave"]').value;
            const bedNumber = row.querySelector('select[name="bedNumber"]')?.value;
    
            if (patientNumber && patientName && onWaitingList && expectedStay && datePlaced && dateLeave && actualLeave && bedNumber) {
                patientAllocations.push({
                    patientNumber,
                    patientName,
                    onWaitingList,
                    expectedStay,
                    datePlaced,
                    dateLeave,
                    actualLeave,
                    bedNumber
                });
            } else {
                console.error('Missing required patient allocation fields', {
                    patientNumber,
                    patientName,
                    onWaitingList,
                    expectedStay,
                    datePlaced,
                    dateLeave,
                    actualLeave,
                    bedNumber
                });
            }
        });
    
        if (patientAllocations.length > 0) {
            return patientAllocations;
        } else {
            return null;
        }
    }
    
    function submitCombinedData(data) {
        fetch('/submit-combined-patient-allocation', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                console.error('Error submitting form:', data.error);
            } else {
                console.log('Form submitted successfully:', data.message);
                window.location.href = '/';
            }
        })
        .catch(error => console.error('Error:', error));
    }
    
    function initializePatientDropdown(patientDropdownRow, patientDropdown) {
        fetch('/get-patients')
            .then(response => response.json())
            .then(data => {
                const blankOption = document.createElement('option');
                blankOption.value = '';
                blankOption.textContent = 'Select Patient';
                patientDropdown.appendChild(blankOption);
    
                data.patients.forEach(patient => {
                    const option = document.createElement('option');
                    option.value = patient.patient_id;
                    option.textContent = patient.patient_id;
                    patientDropdown.appendChild(option);
                });
    
                patientDropdown.addEventListener('change', function() {
                    const patientId = patientDropdown.value;
                    if (patientId) {
                        fetch(`/get-patient-details?patient_id=${patientId}`)
                            .then(response => {
                                if (!response.ok) {
                                    throw new Error('Network response was not ok');
                                }
                                return response.json();
                            })
                            .then(data => {
                                const cells = patientDropdownRow.cells;
                                cells[0].querySelector('select[name="patientNumber"]').value = data.patient_id;
                                cells[1].textContent = `${data.patient_name}`;
                            })
                            .catch(error => console.error('Error fetching patient details:', error));
                    } else {
                        // Clear patient details if no patient is selected
                        const cells = patientDropdownRow.cells;
                        cells[1].querySelector('input[name="patientName"]').value = '';
                    }
                });
            })
            .catch(error => console.error('Error fetching patients:', error));
    }

    function addNewRow() {
        const tableBody = document.getElementById('patientTable');
        const newRow = tableBody.insertRow();
    
        let newCell = newRow.insertCell(0);
        const patientSelect = document.createElement('select');
        patientSelect.name = 'patientNumber';
        patientSelect.className = 'form-control';
        newCell.appendChild(patientSelect);
    
        newCell = newRow.insertCell(1);
        newCell.contentEditable = 'false';
        newCell.innerText = '';
    
        newCell = newRow.insertCell(2);
        const onWaitingList = document.createElement('input');
        onWaitingList.name = 'onWaitingList';
        onWaitingList.type = 'date';
        onWaitingList.className = 'form-control';
        newCell.appendChild(onWaitingList);
    
        newCell = newRow.insertCell(3);
        const expectedStayInput = document.createElement('input');
        expectedStayInput.name = 'expectedStay';
        expectedStayInput.className = 'form-control';
        newCell.appendChild(expectedStayInput);
    
        newCell = newRow.insertCell(4);
        const datePlacedInput = document.createElement('input');
        datePlacedInput.name = 'datePlaced';
        datePlacedInput.type = 'date';
        datePlacedInput.className = 'form-control';
        newCell.appendChild(datePlacedInput);
    
        newCell = newRow.insertCell(5);
        const dateLeaveInput = document.createElement('input');
        dateLeaveInput.name = 'dateLeave';
        dateLeaveInput.type = 'date';
        dateLeaveInput.className = 'form-control';
        newCell.appendChild(dateLeaveInput);
    
        newCell = newRow.insertCell(6);
        const actualLeaveInput = document.createElement('input');
        actualLeaveInput.name = 'actualLeave';
        actualLeaveInput.type = 'date';
        actualLeaveInput.className = 'form-control';
        newCell.appendChild(actualLeaveInput);
    
        newCell = newRow.insertCell(7);
        const bedSelect = document.createElement('select');
        bedSelect.name = 'bedNumber';
        bedSelect.className = 'form-control';
        for (let i = 1; i <= 5; i++) {
            const option = document.createElement('option');
            option.value = i;
            option.textContent = `Bed ${i}`;
            bedSelect.appendChild(option);
        }
        newCell.appendChild(bedSelect);
    
        newCell = newRow.insertCell(8);
        const deleteBtn = document.createElement('button');
        deleteBtn.type = 'button';
        deleteBtn.className = 'btn btn-danger delete-row-btn';
        deleteBtn.innerHTML = '<i class="bi bi-trash"></i>';
        deleteBtn.onclick = function() {
            tableBody.deleteRow(newRow.rowIndex - 1);
        };
        newCell.appendChild(deleteBtn);
    
        initializePatientDropdown(newRow, patientSelect);
    }

    function addQualification() {
        const qualifications = document.getElementById('qualifications');
        const newQualification = document.createElement('div');
        newQualification.classList.add('qualification-entry');
        newQualification.innerHTML = `
            <div class="form-group">
                <label for="qualificationType">Type</label>
                <input type="text" class="form-control" name="qualification_type[]" value="" required>
            </div>
            <div class="form-group">
                <label for="qualificationDate">Date</label>
                <input type="date" class="form-control" name="qualification_date[]" value="" required>
            </div>
            <div class="form-group">
                <label for="qualificationInstitution">Institution</label>
                <input type="text" class="form-control" name="qualification_institution[]" value="" required>
            </div>
        `;
        qualifications.appendChild(newQualification);
    }

    function addWorkExperience() {
        const workExperience = document.getElementById('workExperience');
        const newExperience = document.createElement('div');
        newExperience.classList.add('work-experience-entry');
        newExperience.innerHTML = `
            <div class="form-group">
                <label for="workExperience">Experience</label>
                <input type="text" class="form-control" name="work_experience[]" value="" required>
            </div>
            <div class="form-group">
                <label for="startDate">Start Date</label>
                <input type="date" class="form-control" name="start_date[]" value="" required>
            </div>
            <div class="form-group">
                <label for="finishDate">Finish Date</label>
                <input type="date" class="form-control" name="finish_date[]" value="" required>
            </div>
            <div class="form-group">
                <label for="organization">Organization</label>
                <input type="text" class="form-control" name="organization[]" value="" required>
            </div>
        `;
        workExperience.appendChild(newExperience);
    }

    function initializePopupContent() {
        fetchDrugDetails();
        fetch('/get-staff')
            .then(response => response.json())
            .then(data => {
                staffOptions = data.staff;
                initializeChargeNurseDropdown();
                initializeWardDropdown();
            });

        addFormSubmitListener();
        fetchStaffNumber();
        initializeWardDetailsListener();
        initializeFormSubmissions();
        addPatientFormSubmitListener();
        fetchPatientNumber();
        initializePatientFormSubmissions();

        // Add event listener for "Add New Row" button
        document.getElementById('add-row-btn').addEventListener('click', addNewRow);

        // Ensure any pre-existing delete buttons are initialized
        document.querySelectorAll('.delete-row-btn').forEach(button => {
            button.addEventListener('click', function() {
                const row = button.closest('tr');
                row.parentNode.removeChild(row);
            });
        });
    }

    document.getElementById('add-row-btn').addEventListener('click', addNewRow);

    // Ensure any pre-existing delete buttons are initialized
    document.querySelectorAll('.delete-row-btn').forEach(button => {
        button.addEventListener('click', function() {
            const row = button.closest('tr');
            row.parentNode.removeChild(row);
        });
    });

    initializePopupContent();
});
