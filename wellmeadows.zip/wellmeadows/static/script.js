$(function() {
    $(".datepicker").datepicker({
        dateFormat: "dd-M-yy"
    });
});